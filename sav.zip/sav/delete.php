<?php
    if(isset($_REQUEST['msg'])){
        echo $msg;
    }
?>
<?php
if(isset($_REQUEST['id'])){
    $id=$_REQUEST['id'];
    include('config.php');
    $query="DELETE from `products` where `id`=$id";
    $res=mysqli_query($connect,$query);
    if($res>0){
        echo "<script>window.location.assign('admin_product_table.php?msg=Deleted Successfully')</script>";
    }
    else{
        echo "<script>window.location.assign('admin_product_table.php?msg=Error!! Try again later!')</script>";

    }
}

?>