
<head>
<style>
        .margin{
            margin-top:30px;
        }
    </style>
<head>
    <?php
    include('header.php');
	if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
	?>
	<div class="banner-top">
        <div class="container">
            <h1>Orders</h1>
            <em></em>
        </div>
	<?php
	include('config.php');
	$query= "SELECT * from `registors` where `email`='$email' && `password`='$password'";
	$res= mysqli_query($connect,$query);
	$data=mysqli_fetch_array($res);
    if(isset($_REQUEST['id'])){ ?>
        <div class="conatiner margin">
			<div class="row">
				<div class="col-md-4"></div>
				<div class="col-md-4 bg-danger">
				<form method="post">
				<div class="login-do">
			    <div class="login-mail margin">
					<input type="text" placeholder="<?php echo $data['name']?>" required="" name="name">
					<i  class="glyphicon glyphicon-user"></i>
				</div>
                <div class="login-mail">
					<input type="text" placeholder="<?php echo $data['quantity']?>" required="" name="quantity">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="<?php echo $data['contact']?>" required="" name="contact">
					<i  class="glyphicon glyphicon-phone"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="<?php echo $data['email']?>" required="" name="email">
					<i  class="glyphicon glyphicon-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="<?php echo $data['address']?>" required="" name="address">
					<i class="glyphicon glyphicon-house-fill"></i>
				</div>
				<label class="hvr-skew-backward">
					<input type="submit" value="Submit" name="btnn">
				</label>
				<div class="clearfix"> </div>
				</form>
				</div>
			</div>
		</div>
    <?php
    }
?>

<?php
    include('footer.php');
?>