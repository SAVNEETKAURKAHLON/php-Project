<?php
include('header.php');
?>
<h1>WELCOME ADMIN</h1>
<?php
include('footer.php');
?>