
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>cart</h1>
            <em></em>
        </div>
    </div>
<?php
    if(isset($_REQUEST['id'])){
        $pid=$_REQUEST['id'];
        $uid=$_SESSION['id'];
        $quantity=1;
        $amount=$_REQUEST['price'];
        include('config.php');
        $query_same="SELECT * from `cart` where `product_id`='$pid' and `user_id`='$uid'";
        $result=mysqli_query($connect,$query_same);
        if(mysqli_num_rows($result)>0){
            $data=mysqli_fetch_array($result);
            $id=$data['id'];
            $quant=$data['quantity']+1;
            $total=$quant*$amount;
            $query="UPDATE `cart` SET `quantity`='$quant',`total_amount`='$total' where `id`='$id'";
        }
        else{
            $query="INSERT into `cart` (`user_id`,`product_id`,`quantity`,`total_amount`) VALUE ('$uid','$pid','$quantity','$amount')";
        }
        $res=mysqli_query($connect,$query);
        if($res>0){
            echo "<script>window.location.assign('products.php?msg=item added ')</script>";   
        }    
        else{
            echo "<script>window.location.assign('products.php?msg=item not added ')</script>";   
        } 
    }
   
    include('footer.php');
?>