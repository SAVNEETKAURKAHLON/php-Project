
<head>
    <style>
        .margin{
            margin-top:30px;
        }
    </style>
</head>
<?php
    include ('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>Orders</h1>
            <em></em>
        </div>
    </div>
<?php
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<div class="container">
    <table border="2px" cellspacing="20px" cellpadding="0px" class="margin">
        <tr>
            <th>sno.</th>
            <th>order details</th>
            <th>user_detail</th>
            <th>status</th>
        </tr>
       <?php
       $uid=$_SESSION['id'];
        include('config.php');
        $query="SELECT * from `orders` where `user_id`='$uid'";
        $res=mysqli_query($connect,$query);
        $sno=1;
        while($data=mysqli_fetch_array($res)){
    ?>
    <tr>
        <td><?php echo $sno ?></td>
        <td><a href="order_details.php?oid=<?php echo $data['order_id'];?>"><?php echo $data['order_id'];?></a></td>
        <td><?php echo $data['name'].",".$data['contact'].",".$data['address']?></td>
        <td><?php echo $data['status']?></td>
    </tr>
    <?php
        $sno++;
        }
       ?>
    </table>
</div>
<?php
    include ('footer.php');
?>