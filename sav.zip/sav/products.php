<head>
    <style>
        .margin{
            margin-top:30px;
        }
        .img1{
            height:200px;
            width:330px;
        }
    </style>
</head>
<?php
include('header.php');
?>
<div class="banner-top">
        <div class="container">
            <h1>Products</h1>
            <em></em>
        </div>
	</div>
<div class="container margin">
<div class="row">
    <?php
    include('config.php');
    $query="SELECT * from `products`";
    $res=mysqli_query($connect,$query);
    while($data=mysqli_fetch_array($res)){
        ?>
        <div class="col-md-4 item-grid1 simpleCart_shelfItem">
					<div class=" mid-pop">
					<div class="pro-img">
						<img class="img1" src="product_img/<?php echo $data['image'] ?> "class="img-responsive" alt="">
						<div class="zoom-icon ">
						<a class="picture" href="images/pc.jpg" rel="title" class="b-link-stripe b-animate-go  thickbox"><i class="glyphicon glyphicon-search icon "></i></a>
						<a href="single.html"><i class="glyphicon glyphicon-menu-right icon"></i></a>
						</div>
						</div>
						<div class="mid-1">
						<div class="women">
						<div class="women-top">
							<span><?php echo $data['product_name']?></span>
							<h6><?php echo $data['description'] ?></h6>
							</div>
							<div class="img item_add">
								<a href="#"><img src="images/ca.png" alt=""></a>
							</div>
							<div class="clearfix"></div>
							</div>
							<div class="mid-2">
								<p >$<?php echo $data['product_price']?></p>
								  <div class="block">
									<div class="starbox small ghosting"> </div>
								</div>
								<div class="clearfix"></div>
							</div>
								<a href="add_to_cart.php?id=<?php echo $data['id']?>&price=<?php echo $data['product_price']?>" class="btn btn-danger">ADD TO CART</a>
						</div>
					</div>
	</div>
    <?php
    }
    ?>
</div>
</div>


<?php
include('footer.php');
?>