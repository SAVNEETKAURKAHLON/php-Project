
<head>
<style>
    .margin{
        margin-top:20px;
    }
</style>
</head>
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('admin_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>Product Table</h1>
            <em></em>
        </div>
    </div>
<div class="container">
<table border="2px" cellpadding="20px" class="margin">
    <tr>
    <th>S.NO.</th>
    <th>product name</th>
    <th>product price</th>
    <th>quantity</th>
    <th>description</th>
    <th>product image</th>
    <th>edit</th>
    <th>delete</th>
    </tr>
    <?php
        include('config.php');
        $q="SELECT * from `products`";
        $result=mysqli_query($connect,$q);
        // $image_name=$_FILES['image']['name'];
        // $path=$_FILES['image']['tmp_name'];
        // $new_name=rand()."_".$image_name;
        $sno=1;
        while($data=mysqli_fetch_array($result)){
    ?>
            <tr>
        <td><?php echo $sno?></td>
        <td><?php echo $data['product_name']?></td>
        <td><?php echo $data['product_price']?></td>
        <td><?php echo $data['stock']?></td>
        <td><?php echo $data['description']?></td>
        <!-- <td><?php echo $data['image'] ?></td> -->
        <td><img height="150px" width="200px" src="product_img/<?php echo $data['image'] ?>"></td>  
        <td><a href="update.php?id=<?php echo $data['id']?>">update</a></td>
        <td><a href="delete.php?id=<?php echo $data['id']?>">Delete</a></td>
       </tr>
        <?php
        $sno++;
    }
    ?>
</table>
</div>

<?php
    include('footer.php');
?>