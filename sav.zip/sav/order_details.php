
<?php
    include ('header.php');
    if(!isset($_SESSION['email'])){
        if($_SESSION['user_type']=='user'){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
    else{
        echo "<script>window.location.assign('admin_login.php?msg=please login first')</script>";

    }
}
?>
<div class="banner-top">
        <div class="container">
            <h1>Order Details</h1>
            <em></em>
        </div>
    </div>
<div class="container">
    <table  border="2px" cellpadding="20px" cellspacing="0px" class="margin">
        <tr>
            <th> s no</th>
            <th>product name</th> 
            <th>quantity</th> 
            <th>price</th> 
        </tr>
       <?php
     if(isset($_REQUEST['oid'])){
        $oid=$_REQUEST['oid'];
        include ('config.php');
        $query="SELECT order_detail.*,products.product_name,products.image,products.stock,products.product_price from `order_detail` inner join `products` on order_detail.product_id=products.id WHERE `order_id`='$oid'";
        $res=mysqli_query($connect,$query);
        $sno=1;
        while($data=mysqli_fetch_array($res)){
        ?>
    <tr>
        <td><?php echo $sno?></td>
        <td><?php echo $data['product_name']?></td>
        <td><?php echo $data['quantity']?></td>
        <td><?php echo $data['product_price']?></td>
       
    </tr>
    <?php
    $sno++;
    }
    }
       ?>
    </table>
</div>
<?php
    include ('footer.php');
?>