
<?php
include('header.php');
?>
<div class="banner-top">
        <div class="container">
            <h1>Register</h1>
            <em></em>
        </div>
</div>	
<div class="container">
<?php
    if(isset($_REQUEST['msg'])){
        echo $_REQUEST['msg'] ;
    }
    ?>
		<div class="login">
			<form method="post">
			<div class="col-md-6 login-do">
			<div class="login-mail">
					<input type="text" placeholder="Name" required="" name="name">
					<i  class="glyphicon glyphicon-user"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="Phone Number" required="" name="contact">
					<i  class="glyphicon glyphicon-phone"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="Email" required="" name="email">
					<i  class="glyphicon glyphicon-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="password" placeholder="Password" required="" name="password">
					<i class="glyphicon glyphicon-lock"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="address" required="" name="address">
					<i class="glyphicon glyphicon-house"></i>
				</div>
				   <a class="news-letter " href="#">
						 <label class="checkbox1"><input type="checkbox" name="checkbox" ><i> </i>Forget Password</label>
					   </a>
				<label class="hvr-skew-backward">
					<input type="submit" value="Submit" name="btnn">
				</label>
			
			</div>
			<div class="col-md-6 login-right">
				 <h3>Completely Free Account</h3>
				 
				 <p>Pellentesque neque leo, dictum sit amet accumsan non, dignissim ac mauris. Mauris rhoncus, lectus tincidunt tempus aliquam, odio 
				 libero tincidunt metus, sed euismod elit enim ut mi. Nulla porttitor et dolor sed condimentum. Praesent porttitor lorem dui, in pulvinar enim rhoncus vitae. Curabitur tincidunt, turpis ac lobortis hendrerit, ex elit vestibulum est, at faucibus erat ligula non neque.</p>
				<a href="login.html" class="hvr-skew-backward">Login</a>

			</div>
			
			<div class="clearfix"> </div>
			</form>
		</div>

</div>
<?php
include('footer.php');
?>
<?php
    if(isset($_REQUEST['btnn'])){
        $email=$_REQUEST['email'];
        $name=$_REQUEST['name'];
        $contact=$_REQUEST['contact'];
        $address=$_REQUEST['address'];
        $password=md5($_REQUEST['password']);
        include('config.php');
       echo $query="INSERT into `registors` (`name`,`email`,`password`,`contact`,`address`) VALUES ('$name','$email','$password','$contact','$address')";
       echo $res= mysqli_query($connect,$query);
       if($res>0){
		$query1= "SELECT * from `registors` where `email`='$email' && `password`='$password'";
        $res1= mysqli_query($connect,$query1);
		$data=mysqli_fetch_array($res1);
		$_SESSION['id']=$data['id'];
		$_SESSION['email']=$email;
		$_SESSION['user_type']='user';
        echo "<script>window.location.assign('index.php')</script>";
       }
       else{
        echo "<script>window.location.assign('register.php?msg=error try again later')</script>";
    }
}
?>
