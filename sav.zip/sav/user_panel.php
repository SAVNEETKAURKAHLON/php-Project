
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<style>
    .head1{
         margin-top:30px;
    }
    .height_img{
        height:200px;
        width:287px;
    }
    .margin{
        margin-top:8px;
    }
</style>
<div class="container">
            <h1>Products</h1>
            <em></em>
        </div>
<div class="container">
    <div class="row">
    <?php
        include('config.php');
        $q="SELECT * from `products`";
        $result=mysqli_query($connect,$q);
        $sno=1;
        while($data=mysqli_fetch_array($result)){
        ?>
            <div class="col-md-4 head1">
            <div class="card bg-danger" style="width: 18rem;">
            <img src="product_img/<?php echo $data['image']?>" class="card-img-top height_img" alt="..." >
            <div class="card-body">
              <h5 class="card-title margin"><?php echo $data['product_name'];?></h5>
              <p class="card-text margin"><?php echo $data['description']; ?> </p>
              <a href="order_form.php" class="btn btn-primary" name="order">PLACE ORDER</a>
            
            </div>
          </div>
            </div>
       <?php
        }
        ?>
   </div>
</div>
<?php
    include('footer.php');
?>