
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('admin_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>Insert Products</h1>
            <em></em>
        </div>
    </div>
<div class="container">
<?php
    if(isset($_REQUEST['msg'])){
        echo $_REQUEST['msg'] ;
    }
    ?>
		<div class="login">
			<form method="post" enctype="multipart/form-data">
                <div class="col-md-3"></div>
			<div class="col-md-6 login-do">
			<div class="login-mail">
					<input type="text" placeholder="product_name" required="" name="name">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="product_price" required="" name="price">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="quantity" required="" name="stock">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="description" required="" name="description">
				</div>
                <div class="login-mail">
					<input type="file" placeholder="quantity" required="" name="image">
				</div>
				<label class="hvr-skew-backward">
					<input type="submit" value="Submit" name="btnn">
				</label>
			
			</div>
			
			
			<div class="clearfix"> </div>
			</form>
		</div>

</div>
<?php
    include('footer.php');
?>
<?php
    if(isset($_REQUEST['btnn'])){
        $name=$_REQUEST['name'];
        $price=$_REQUEST['price'];
        $quantity=$_REQUEST['stock'];
        $description=$_REQUEST['description'];
        $image_name=$_FILES['image']['name'];
        $path=$_FILES['image']['tmp_name'];
        $new_name=rand()."_".$image_name;
        include('config.php');
       echo $query="INSERT into `products` (`product_name`,`product_price`,`stock`,`description`,`image`) VALUES ('$name','$price','$quantity','$description','$new_name')";
       echo $res= mysqli_query($connect,$query);
        if($res>0){
         move_uploaded_file($path,'product_img/'.$new_name);
         echo "<script>window.location.assign('admin_product_insert.php')</script>";
        }
         else{
        echo "<script>window.location.assign('admin_product_insert.php?msg=error try again later')</script>";
    }
}
?>