
<style>
    #quant{
        width:30px;
    }
</style>
<?php
include('header.php');
if(!isset($_SESSION['email'])){
    echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
}
?>
<div class="banner-top">
        <div class="container">
            <h1>Order Table</h1>
            <em></em>
        </div>
    </div>
<body>
<div class="container">
<table border="2px" cellpadding="20px" cellspacing="0px">
    <tr>
        <th>s no.</th>
        <th>product</th>
        <th>Image</th>
        <th>quantity</th>
        <th>price</th>
        <th>total price</th>
    </tr>
    <?php
        $uid=$_SESSION['id'];
        include('config.php');
        $q="SELECT cart.*,products.product_name,products.image,products.stock,products.product_price from `cart` inner join `products` on cart.product_id=products.id WHERE `user_id`='$uid'";
        $result=mysqli_query($connect,$q);
        $sno=1;
        while($data=mysqli_fetch_array($result)){
    ?>
    
        <tr>
        <td><?php echo $sno ?></td>
       <td><?php echo $data['product_name'];?></td>
       <td> <img src="product_img/<?php echo $data['image'];?>" height="150px" width="250px"></td>
       <td >
            <form>
                <button type="submit" name="button" value="dec">-</button>
                <input type="" readonly value="<?php echo $data['quantity'];?>" id="quant" name="quantity" min="0">
                <input type="HIDDEN" name="id" value="<?php echo $data['id']?>">
                <input type="HIDDEN" name="price" value="<?php echo $data['product_price']?>">
                <button type="submit" name="button" value="inc">+</button>
            </form>
        </td>
       <td id="price"><?php echo $data['product_price'];?></td>
       <td id="final_price"><?php echo $data['total_amount'];?></td>
        </tr>
        <?php
        $sno++;
    }
    ?>
</table>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-5 bg bg-danger margin">
        <form method="post">
            <div class="row">
            <div class="col-md-12 login-do">
			<div class="login-mail margin">
					<input type="text" value="" placeholder="name" required="" name="name">
					<i  class="glyphicon glyphicon-user"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="Phone Number" required="" name="contact">
					<i  class="glyphicon glyphicon-phone"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="Email" required="" name="email">
					<i  class="glyphicon glyphicon-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="text" placeholder="address" required="" name="address">
					<i class="glyphicon glyphicon-house"></i>
				</div>
				<label class="hvr-skew-backward">
					<input type="submit" value="Submit" name="place_order">
				</label>
			</div>
			<div class="clearfix"> </div>
            </div>
			</form>
        </div>
    </div>
</div>
<?php
include('footer.php');
?>
<!-- <script>
        function fun(){
            x=document.getElementById('quant').value;
            y=document.getElementById('price').innerHTML;
            document.getElementById('final_price').innerHTML=parseInt(x)*parseInt(y);
        }
</script> -->
</body>
<?php
if(isset($_REQUEST['button'])){
    $quanti=$_REQUEST['quantity']-1;
    $quantity=$_REQUEST['quantity']+1;
    $price=$_REQUEST['price'];
    $id=$_REQUEST['id'];
    include 'config.php';
    if($_REQUEST['button']=='inc'){
        $amt=$quantity*$price;
        echo $amt;
        $query="UPDATE `cart` SET `quantity`='$quantity',`total_amount`='$amt' WHERE `id`=$id ";
        $res=mysqli_query($connect,$query);
    }
    else{
        if($quanti>0){
            $amt=$quanti*$price;
            $query1="UPDATE `cart` SET `quantity`='$quanti', `total_amount`='$amt' WHERE `id`=$id ";
            $res=mysqli_query($connect,$query1);
        }
        else{
            include('config.php');
            $query="DELETE from `cart` where `id`=$id";
            $res=mysqli_query($connect,$query);
        }
       
    }
}
?>
<?php
    if(isset($_REQUEST['place_order'])){
	$name=$_REQUEST['name'];
	$email=$_REQUEST['email'];
	$contact=$_REQUEST['contact'];
	$address=$_REQUEST['address'];
	$order_id="OD".rand();
	include('config.php');
     $query_cart="SELECT * from `cart` where `user_id`=$uid";
     $res_cart=mysqli_query($connect,$query_cart);
     print_r ($res_cart);
    if(mysqli_num_rows($res_cart)<1){
        "window.location.assign=order_table.php?msg=no item in cart";
    }
    else{
        $que="INSERT into `orders` (`order_id`,`user_id`,`name`,`contact`,`address`) VALUES ('$order_id','$uid','$name','$contact','$address')";
        $res=mysqli_query($connect,$que);
       if($res>0){
    while ($d=mysqli_fetch_array($res_cart)){

            $p_id=$d['product_id'];
            $quantity=$d['quantity'];
            $total_price=$d['total_amount'];
            $cart_id=$d['id'];    
           echo $query_insert="INSERT into `order_detail` (`order_id`,`product_id`,`quantity`,`total_price`) VALUES ('$order_id','$p_id','$quantity','$total_price')";
            $res_insert=mysqli_query($connect,$query_insert);
            if($res>0){
                include('config.php');
                $query_delete="DELETE from `cart` where `id`=$cart_id";
                $res_delete=mysqli_query($connect,$query_delete);
                if($res_delete>0){
                    echo "<script>window.location.assign('order_table.php?msg=order placed')</script>";
                }
                else{
                    echo "<script>window.location.assign('order_table.php?msg=order not placed')</script>";
                }
            }
        }
    }
    }
    }
?>
