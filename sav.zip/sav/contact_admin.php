
<head>
    <style>
        .margin{
            margin-top:20px;
        }
    </style>
</head>
<?php   
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('admin_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>contact</h1>
            <em></em>
        </div>
</div>
<div class="container margin">
    <div class="col-md-2"></div>
    <div class="col-md-8">
        <table border="3px" cellpadding="20px" cellspacing="0px">
            <th>s no</th>
            <th>user id</th>
            <th>name</th>
            <th>email</th>
            <th>message</th>
    </div>
</div>
<?php
    include ('config.php');
    $query="SELECT * from `contact`";
    $res=mysqli_query($connect,$query);
    $sno=1;
    while($data=mysqli_fetch_array($res)){
        ?>
        <tr>
        <td><?php echo $sno;?></td>
        <td><?php echo $data['user_id'];?></a></td>
        <td><?php echo $data['name']?></td>
        <td><?php echo $data['email']?></td>
        <td><?php echo $data['comment']?></td>
        </tr>
        <?php
        $sno++;
        }
?>
</table>
<?php   
    include('footer.php');
?>