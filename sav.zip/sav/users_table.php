
<head>
<style>
    .margin{
        margin-top:20px;
    }
</style>
</head>
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
 <div class="container">
            <h1>User Details</h1>
            <em></em>
        </div>
<div class="container">
<table border="2px" cellpadding="20px" class="margin">
    <tr>
    <th>S.NO.</th>
    <th>user name</th>
    <th>email</th>
    <th>contact</th>
    <th>address</th>
    </tr>
    <?php
        include('config.php');
        $q="SELECT * from `registors`";
        $result=mysqli_query($connect,$q);
        $sno=1;
        while($data=mysqli_fetch_array($result)){
    ?>
            <tr>
        <td><?php echo $sno?></td>
        <td><?php echo $data['name']?></td>
        <td><?php echo $data['email']?></td>
        <td><?php echo $data['contact']?></td>
        <td><?php echo $data['address']?></td>
       </tr>
        <?php
        $sno++;
    }
    ?>
</table>
</div>

<?php
    include('footer.php');
?>