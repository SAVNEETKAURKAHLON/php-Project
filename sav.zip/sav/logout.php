
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>Logout</h1>
            <em></em>
        </div>
    </div>
<?php
    $type=$_SESSION['user_type'];
    if($type=='admin'){
        session_unset();
        echo "<script>window.location.assign('admin_login.php?msg=logout successfully')</script>";
    }
    else{
        session_unset();
        echo "<script>window.location.assign('user_login.php?msg=logout successfully')</script>";
    }
?>

<?php
    include('footer.php');
?>