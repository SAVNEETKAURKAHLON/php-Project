
<?php
    include('header.php');
?>
<head>
    <style>
        .margin{
            margin-top:20px;
        }
        .margin2{
            margin-top:5px;
        }
    </style>
</head>
 <div class="banner-top">
        <div class="container">
            <h1>Update</h1>
            <em></em>
        </div>
</div>
<?php
    if(isset($_REQUEST['id'])){
        $id=$_REQUEST['id'];
        include('config.php');
        $query="SELECT * from `products` where `id`='$id'";
        $result=mysqli_query($connect,$query);
        $data=mysqli_fetch_array($result);
    }
?>
<div class="container">
<div class="col-md-4"></div>
<div class="col-md-4 margin bg-danger">
        <div class="login">
			<form method="post">
			<div class="col-md-12 login-do">
			<div class="login-mail">
					<input type="text" class="margin2" placeholder="product_name" required="" name="product_name" value="<?php echo $data['product_name']?>">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="Product_price" required="" name="product_price" value="<?php echo $data['product_price']?>">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="stock" required="" name="stock" value="<?php echo $data['stock']?>">
				</div>
				<div class="login-mail">
					<input type="text" placeholder="desciption" required="" name="description" value="<?php echo $data['description']?>">
				</div>
				<div class="login-mail">
                    <input type="file" name="image">
                    <input type="hidden" name="hidimage" class="margin"  value="<?php echo $data['image']?>">    <br>
                    <input type="hidden" name="id" class="margin"  value="<?php echo $data['id']?>">
				</div>
				  
				<label class="hvr-skew-backward">
					<input type="submit" value="Submit" name="btnn">
				</label>
			
			</div>
			<div class="clearfix"> </div>
			</form>
		</div>
        </div>


<!-- <div class="col-md-4 bg-danger margin">
        <form method="post" enctype="multipart/form-data">
    product name:<input type="text" class="margin" name="product_name" value="<?php echo $data['product_name']?>">
    <br>
    product price:<input type="text" class="margin"  name="product_price" value="<?php echo $data['product_price']?>">
    <br>
    quantity:<input type="number" class="margin"  name="quantity" value="<?php echo $data['stock']?>">
    <br>
    description:
    <input type="text" name="description" class="margin"   value="<?php echo $data['description']?>">
    <br> 
    image:
    <input type="file" name="image" class="margin" >
    <input type="hidden" name="hidimage" class="margin"  value="<?php echo $data['image']?>">    <br>
    <input type="hidden" name="id" class="margin"  value="<?php echo $data['id']?>">
    <button name="btn">Submit</button>
        </form>
 </div>-->
    </div>
</div> 

<?php
    if(isset($_REQUEST['btn'])){
        $id=$_REQUEST['id'];
        $product_name=$_REQUEST['product_name'];
        $product_price=$_REQUEST['product_price'];
        $quantity=$_REQUEST['stock'];
        $description=$_REQUEST['description'];
        if($_FILES['image']['name']!=""){
            $img_name=$_FILES['image']['name'];
            $img_path=$_FILES['image']['tmp_name'];
            $new_name=rand()."_".$img_name;
            move_uploaded_file($img_path,'product_img/'.$new_name);
        }
        else{
            $new_name=$_REQUEST['hidimage'];
        }
        include('config.php');
         echo $q="UPDATE `products` SET `product_name`='$product_name',`product_price`='$product_price',`stock`='$quantity',`description`='$description',`image`='$new_name' WHERE `id`=$id";
        $res=mysqli_query($connect,$q);
        if($res>0){
            echo "<script>window.location.assign('admin_product_table.php?msg= Updated successfully')</script>";
        }
        else{
            echo "<script>window.location.assign('admin_product_table.php?msg=Try again later)</script>";
        }
        }

?>
<?php
include('footer.php')
?>