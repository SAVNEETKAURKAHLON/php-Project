
<head>
    <style>
        .margin{
            margin-top:30px;
        }
    </style>
</head>
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>order table</h1>
            <em></em>
        </div>
</div>
<div class="container">
<table border="2px" cellpadding="20px" cellspacing="0px" class="margin">
    <tr>
       <th>s no.</th> 
       <th>order details</th> 
       <th>status</th> 
    </tr>
</div>

<?php
    include('footer.php');
?>
<?php
    // $uid=$_REQUEST['user_id'];
    include ('config.php');
    $query="SELECT cart.*,products.product_name from `cart` inner join `products` on cart.product_id=products.id";
    $res=mysqli_query($connect,$query);
    $sno=1;
    while($data=mysqli_fetch_array($res)){
        ?>
        <tr>
        <td><?php echo $sno;?></td>
        <td><a href="user_order_details.php?uid=<?php echo $data['user_id'];?>"><?php echo $data['user_id'];?></a></td>
        <!-- <td><?php echo $data['product_name'].",".$data['total_amount'].",".$data['quantity'];?></td> -->
        <td><?php echo $data['status']?></td>
        <td>
        </tr>
        <?php
        $sno++;
        }

?>
    </table>
