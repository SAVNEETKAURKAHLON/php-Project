
<?php
include('header.php');
?>
<div class="banner-top">
        <div class="container">
            <h1>login</h1>
            <em></em>
        </div>
    </div>
<div class="container">
    <?php
    if(isset($_REQUEST['msg'])){
        echo $_REQUEST['msg'] ;
    }
    ?>
		<div class="login">
		
			<form method="post">
			<div class="col-md-6 login-do">
				<div class="login-mail">
					<input type="text" placeholder="Email" required="" name="email">
					<i  class="glyphicon glyphicon-envelope"></i>
				</div>
				<div class="login-mail">
					<input type="password" placeholder="Password" required="" name="password">
					<i class="glyphicon glyphicon-lock"></i>
				</div>
				   <a class="news-letter " href="#">
						 <label class="checkbox1"><input type="checkbox" name="checkbox" ><i> </i>Forget Password</label>
					   </a>
				<label class="hvr-skew-backward">
					<input type="submit" value="login" name="btnn">
				</label>
			</div>
			<div class="col-md-6 login-right">
				 <h3>Completely Free Account</h3>
				 
				 <p>Pellentesque neque leo, dictum sit amet accumsan non, dignissim ac mauris. Mauris rhoncus, lectus tincidunt tempus aliquam, odio 
				 libero tincidunt metus, sed euismod elit enim ut mi. Nulla porttitor et dolor sed condimentum. Praesent porttitor lorem dui, in pulvinar enim rhoncus vitae. Curabitur tincidunt, turpis ac lobortis hendrerit, ex elit vestibulum est, at faucibus erat ligula non neque.</p>
				<a href="register.html" class=" hvr-skew-backward">Register</a>

			</div>
			
			<div class="clearfix"> </div>
			</form>
		</div>

</div>
<?php
include('footer.php');
?>
<?php
    if(isset($_REQUEST['btnn'])){
        $email=$_REQUEST['email'];
        $password=md5($_REQUEST['password']);
        include('config.php');
        $query= "SELECT * from `admin` where `email`='$email' && `password`='$password'";
        $res= mysqli_query($connect,$query);
		$data=mysqli_fetch_array($res);
    if(mysqli_num_rows($res)>0){
		$_SESSION['id']=$data['id'];
		$_SESSION['email']=$email;
		$_SESSION['user_type']='admin';
        echo "<script>window.location.assign('admin_order_table.php')</script>";
    }
    else{
        echo "<script>window.location.assign('admin_login.php?msg=enter valid details')</script>";
    }
}
?>