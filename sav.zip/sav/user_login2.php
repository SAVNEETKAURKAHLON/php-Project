<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('user_login.php?msg=please login first')</script>";
    }
?>
<h1>WELCOME <?php echo $_SESSION['email']; ?></h1>
<?php
    include('footer.php')
?>