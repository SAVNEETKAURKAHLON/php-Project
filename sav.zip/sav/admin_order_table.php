
<head>
    <style>
        .margin{
            margin-top:30px;
        }
    </style>
</head>
<?php
    include('header.php');
    if(!isset($_SESSION['email'])){
        echo "<script>window.location.assign('admin_login.php?msg=please login first')</script>";
    }
?>
<div class="banner-top">
        <div class="container">
            <h1>Order Table</h1>
            <em></em>
        </div>
    </div>
<div class="container">
<table border="2px" cellpadding="20px" cellspacing="0px" class="margin">
    <tr>
       <th>s no.</th> 
       <th>order id</th> 
       <th>user details</th> 
       <th>status</th> 
       <th>action</th> 
    </tr>
</div>

<?php
    include ('config.php');
    $query="SELECT * from `orders` order by `id` desc ";
    $res=mysqli_query($connect,$query);
    $sno=1;
    while($data=mysqli_fetch_array($res)){
    ?>
    <tr>
        <td><?php echo $sno;?></td>
        <td><a href="order_details.php?oid=<?php echo $data['order_id'];?>"><?php echo $data['order_id'];?></a></td>
        <td><?php echo $data['name'].",".$data['contact'].",".$data['address']?></td>
        <td><?php echo $data['status']?></td>
        <td>
            <?php
                $status=$data['status'];
                    if($status!='cancelled'|| $status!='shipped'){
                        ?>
            <form method="post">
                <input type="hidden" name="id" value="<?php echo $data['id']?>">
                <?php
                    if($status=="pending"){
                        ?>
                        <button type="submit" value="accepted" name="btn">ACCEPT</button>
                        <button  value="rejected" name="btn">REJECT</button>
                        <?php
                    }
                    elseif($status=="accepted"){
                        ?>
                        <button type="submit" value="packed" name="btn">PACK</button>
                        <button  value="rejected" name="btn">REJECT</button>
                        <?php
                    }
                    elseif($status=="packed"){
                        ?>
                        <button type="submit" value="shipped" name="btn">SHIP</button>
                        <?php
                    }

                }
                else{
                    echo $status;
                }
                ?>
            </form>
        </td>
    </tr>
   <?php 
    $sno++;
}
if(isset($_REQUEST['btn'])){
   echo $btn=$_REQUEST['btn'];
   $oid=$_REQUEST['id'];
   include('config.php');
   $query_update="UPDATE `orders` SET `status`='$btn' where `id`='$oid'";
   $res_update=mysqli_query($connect,$query_update);
   if($res_update>0){
    echo "<script>window.location.assign('admin_order_table.php?msg=status updated')</script>";
   }
}
?>
</table>
<?php
    include('footer.php');
?>